"""
main.py — Screener document downloader (v2 — type-safe pipeline).

Every document carries an explicit document_type from discovery through download.
Filenames are generated from document_type, never inferred from quarter labels.

Run:
    python main.py --company ACE --base "C:/Users/Ram/Research"
    python main.py --url https://www.screener.in/company/ACE/consolidated/ --base "C:/Users/Ram/Research"
"""

import argparse
import re
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

try:
    import pypdf
    PYPDF_AVAILABLE = True
except ImportError:
    PYPDF_AVAILABLE = False

# ── Document types ─────────────────────────────────────────────────────────────
ANNUAL_REPORT         = "annual_report"
CREDIT_REPORT         = "credit_report"
QUARTERLY_RESULT      = "quarterly_result"
INVESTOR_PRESENTATION = "investor_presentation"
TRANSCRIPT            = "transcript"

TYPE_TO_FOLDER = {
    ANNUAL_REPORT:         "Annual Reports",
    CREDIT_REPORT:         "Credit Reports",
    QUARTERLY_RESULT:      "Quarterly Results",
    INVESTOR_PRESENTATION: "Investor Presentations",
    TRANSCRIPT:            "Concall Transcripts",
}


def make_filename(doc_type: str, label: str) -> str:
    """Generate filename purely from doc_type. Never infer type from label."""
    if doc_type == ANNUAL_REPORT:
        return f"{label} Annual Report.pdf"
    if doc_type == CREDIT_REPORT:
        return f"{label} Credit Rating.pdf"
    if doc_type == QUARTERLY_RESULT:
        return f"{label} Results.pdf"
    if doc_type == INVESTOR_PRESENTATION:
        return f"{label} Investor Presentation.pdf"
    if doc_type == TRANSCRIPT:
        return f"{label} Transcript.pdf"
    return f"{label}.pdf"


# ── Document dataclass ─────────────────────────────────────────────────────────
@dataclass
class Document:
    document_type: str    # one of the constants above — never changes after creation
    label:         str    # e.g. "Q4FY26", "FY26", "2025-04"
    url:           str    # source URL
    date_display:  str    # human-readable, for terminal output
    filename:      str = field(init=False)
    source:        str = ""   # "screener_annual" | "screener_credit" | "screener_concall" | "bse"
    subject:       str = ""   # BSE NEWSSUB, for debug

    def __post_init__(self):
        self.filename = make_filename(self.document_type, self.label)

    @property
    def dedup_key(self) -> tuple:
        """Deduplication key: one file per (label, type)."""
        return (self.label, self.document_type)


# ── Constants ──────────────────────────────────────────────────────────────────
SCREENER_BASE   = "https://www.screener.in"
SCREENER_SEARCH = "https://www.screener.in/api/company/search/"
YEARS_BACK      = 7
CUTOFF_YEAR     = datetime.now().year - YEARS_BACK
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
}

MONTH_NAME = {
    "jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
    "jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12,
    "january":1,"february":2,"march":3,"april":4,"june":6,
    "july":7,"august":8,"september":9,"october":10,
    "november":11,"december":12,
}

# Month of announcement → (Indian quarter, FY-end year offset)
MONTH_TO_QUARTER = {
    1:("Q3",0), 2:("Q3",0), 3:("Q3",0),
    4:("Q4",0), 5:("Q4",0), 6:("Q4",0),
    7:("Q1",1), 8:("Q1",1), 9:("Q1",1),
    10:("Q2",1),11:("Q2",1),12:("Q2",1),
}

# BSE subcategories that indicate actual financial results
BSE_RESULT_SUBCATS = {
    "financial results", "quarterly results", "half yearly results",
    "annual results", "standalone financial results",
    "consolidated financial results",
}

# Keywords that indicate a board meeting notice — always skip
BSE_NOTICE_KEYWORDS = [
    "board meeting intimation", "intimation of board",
    "prior intimation", "notice of board",
    "outcome of board", "outcome of the board",
]

# Keywords that reveal a doc is a transcript even when filed under "Results"
BSE_TRANSCRIPT_KEYWORDS = [
    "earnings call transcript", "concall transcript",
    "conference call transcript", "transcript of",
    "q1 transcript", "q2 transcript", "q3 transcript", "q4 transcript",
]

# Keywords that reveal a doc is a presentation even when filed under "Results"
BSE_PRESENTATION_KEYWORDS = [
    "investor presentation", "earnings presentation",
    "corporate presentation", "investor meet presentation",
    "analyst presentation",
]


# ══════════════════════════════════════════════════════════════════════
# QUARTER / FY LABEL HELPERS
# ══════════════════════════════════════════════════════════════════════

def quarter_from_text(text: str):
    """Extract (Qx, YY) from text like 'Q4 FY26' or 'Q4FY2026'. Returns None if not found."""
    m = re.search(r'\b(Q[1-4])\s*[-–]?\s*FY\s*(20)?(\d{2})\b', text, re.IGNORECASE)
    if m:
        return m.group(1).upper(), m.group(3)
    return None


def label_from_month(date_label: str) -> str:
    """Convert 'May 2026' → 'Q4FY26'. Falls back to 'May2026' if parsing fails."""
    parts = date_label.lower().split()
    month_num = year = None
    for p in parts:
        if p in MONTH_NAME:
            month_num = MONTH_NAME[p]
        try:
            y = int(p)
            if 2000 <= y <= 2099:
                year = y
        except ValueError:
            pass
    if month_num and year:
        q, offset = MONTH_TO_QUARTER.get(month_num, ("Q?", 0))
        fy = str(year + offset)[-2:]
        return f"{q}FY{fy}"
    return date_label.replace(" ", "")


def label_from_bse_date(news_dt: str) -> str:
    """Convert '2025-08-14' → 'Q1FY26'."""
    try:
        dt = datetime.strptime(news_dt[:10], "%Y-%m-%d")
        return label_from_month(dt.strftime("%b %Y"))
    except Exception:
        return "UnknownQ"


def fy_from_title(title: str) -> str:
    """'Financial Year 2025' → 'FY25'."""
    m = re.search(r'\b(20\d{2})\b', title)
    return f"FY{m.group(1)[-2:]}" if m else "FY??"


def credit_label_from_text(text: str) -> str:
    """Extract 'YYYY-MM' from credit rating date text."""
    yr_m  = re.search(r'\b(20\d{2})\b', text)
    mon_m = re.search(
        r'\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\b',
        text, re.IGNORECASE
    )
    year = yr_m.group(1) if yr_m else "????"
    if mon_m:
        mon_num = str(MONTH_NAME.get(mon_m.group(1)[:3].lower(), "??")).zfill(2)
    else:
        mon_num = "??"
    return f"{year}-{mon_num}"


# ══════════════════════════════════════════════════════════════════════
# COMPANY RESOLUTION
# ══════════════════════════════════════════════════════════════════════

def resolve_company(raw: str) -> tuple:
    if "screener.in/company/" in raw:
        url   = raw if raw.startswith("http") else "https://" + raw
        parts = url.rstrip("/").split("/")
        name  = next(
            (p for p in reversed(parts) if p and p not in ("consolidated","standalone")),
            "COMPANY"
        )
        return name.upper(), url

    print(f"\nSearching Screener for '{raw}'...")
    try:
        resp = requests.get(SCREENER_SEARCH, params={"q": raw, "v": "3"},
                            headers=HEADERS, timeout=15)
        resp.raise_for_status()
        results = resp.json()
    except Exception as e:
        print(f"Search failed: {e}")
        sys.exit(1)

    if not results:
        print(f"No companies found for '{raw}'.")
        sys.exit(1)

    if len(results) == 1:
        r = results[0]
        print(f"Found: {r['name']}")
        return r["name"], SCREENER_BASE + r["url"]

    print("\nMultiple companies found:\n")
    for i, r in enumerate(results[:10], 1):
        print(f"  {i}. {r['name']}  ({r['url']})")
    while True:
        ch = input("\nChoose number (0 to cancel): ").strip()
        if ch == "0":
            sys.exit(0)
        try:
            idx = int(ch) - 1
            if 0 <= idx < len(results):
                r = results[idx]
                return r["name"], SCREENER_BASE + r["url"]
        except ValueError:
            pass


# ══════════════════════════════════════════════════════════════════════
# SCREENER DISCOVERY
# ══════════════════════════════════════════════════════════════════════

def _siblings_html(heading_tag) -> BeautifulSoup:
    siblings = []
    for sib in heading_tag.find_next_siblings():
        if sib.name in ["h2","h3","h4"]:
            break
        siblings.append(str(sib))
    return BeautifulSoup("".join(siblings), "lxml")


def discover_annual_reports(soup: BeautifulSoup) -> list[Document]:
    docs = []
    for h in soup.find_all(["h2","h3"]):
        if "annual report" not in h.get_text().lower():
            continue
        for li in _siblings_html(h).find_all("li"):
            a = li.find("a", href=True)
            if not a:
                continue
            title  = li.get_text(" ", strip=True)
            yr     = re.search(r'\b(20\d{2})\b', title)
            if yr and int(yr.group(1)) <= CUTOFF_YEAR:
                continue
            label  = fy_from_title(title)
            docs.append(Document(
                document_type = ANNUAL_REPORT,
                label         = label,
                url           = a["href"],
                date_display  = title,
                source        = "screener_annual",
            ))
        break
    return docs


def discover_credit_reports(soup: BeautifulSoup) -> list[Document]:
    docs = []
    for h in soup.find_all(["h2","h3"]):
        if "credit" not in h.get_text().lower() and "rating" not in h.get_text().lower():
            continue
        for li in _siblings_html(h).find_all("li"):
            a = li.find("a", href=True)
            if not a:
                continue
            text  = li.get_text(" ", strip=True)
            yr    = re.search(r'\b(20\d{2})\b', text)
            if yr and int(yr.group(1)) <= CUTOFF_YEAR:
                continue
            label = credit_label_from_text(text)
            docs.append(Document(
                document_type = CREDIT_REPORT,
                label         = label,
                url           = a["href"],
                date_display  = text,
                source        = "screener_credit",
            ))
        break
    return docs


def discover_concalls_playwright(url: str) -> list[Document]:
    """
    Playwright: confirmed selector 'div.documents.concalls li.flex'.
    Date: <div style='width: 74px'>May 2026</div>
    Transcript: <a class='concall-link' title='Raw Transcript'>Transcript</a>
    PPT:        <a class='concall-link'>PPT</a>
    Classification: link TEXT determines type — not filename, not URL.
    """
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

    print("  Opening browser for concalls (Playwright)...")
    html = ""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page    = browser.new_page()
        page.set_extra_http_headers(HEADERS)
        page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        try:
            page.wait_for_selector("#documents", timeout=15_000)
        except PWTimeout:
            browser.close()
            print("  WARNING: #documents not found.")
            return []
        page.evaluate("document.querySelector('#documents').scrollIntoView()")
        page.wait_for_timeout(2000)
        try:
            page.wait_for_selector("div.documents.concalls li.flex", timeout=10_000)
            html = page.inner_html("div.documents.concalls")
        except PWTimeout:
            print("  WARNING: Concalls list not rendered.")
        browser.close()

    if not html:
        return []

    soup = BeautifulSoup(html, "lxml")
    rows = soup.find_all("li", class_=lambda c: c and "flex" in c and "flex-gap-8" in c)
    print(f"  Found {len(rows)} concall rows")

    docs = []
    for row in rows:
        date_div = row.find("div", style=lambda s: s and "width: 74px" in s)
        if not date_div:
            continue
        date_label = date_div.get_text(strip=True)
        yr = re.search(r'\b(20\d{2})\b', date_label)
        if yr and int(yr.group(1)) <= CUTOFF_YEAR:
            continue

        label = label_from_month(date_label)

        for a in row.find_all("a", class_="concall-link", href=True):
            href      = a["href"]
            link_text = a.get_text(strip=True)   # "Transcript" or "PPT"
            title_att = (a.get("title") or "")

            # Skip audio/video
            if any(x in href.lower() for x in
                   [".mp3",".mp4","youtube.com","ccreservations.com","drive.google.com"]):
                continue

            # ── Classification by link TEXT, not URL ──────────────────────────
            if link_text == "Transcript" or "Raw Transcript" in title_att:
                doc_type = TRANSCRIPT
            elif link_text == "PPT":
                doc_type = INVESTOR_PRESENTATION
            else:
                continue   # AI Summary, REC — skip

            docs.append(Document(
                document_type = doc_type,
                label         = label,
                url           = href,
                date_display  = date_label,
                source        = "screener_concall",
            ))

    return docs


# ══════════════════════════════════════════════════════════════════════
# BSE QUARTERLY RESULTS DISCOVERY
# ══════════════════════════════════════════════════════════════════════

def classify_bse_announcement(newssub: str, subcat: str) -> str | None:
    """
    Returns one of the document_type constants, or None to skip.
    Priority:
      1. Reject notices entirely.
      2. Detect transcripts by NEWSSUB keywords (even if filed under Results).
      3. Detect presentations by NEWSSUB keywords.
      4. Accept as quarterly_result if subcat matches known result subcats.
      5. Otherwise skip.
    """
    text = newssub.lower()

    # 1. Reject notices
    for kw in BSE_NOTICE_KEYWORDS:
        if kw in text:
            return None

    # 2. Transcript detection (overrides subcat)
    for kw in BSE_TRANSCRIPT_KEYWORDS:
        if kw in text:
            return TRANSCRIPT

    # 3. Presentation detection (overrides subcat)
    for kw in BSE_PRESENTATION_KEYWORDS:
        if kw in text:
            return INVESTOR_PRESENTATION

    # 4. Actual results
    if subcat.lower() in BSE_RESULT_SUBCATS:
        return QUARTERLY_RESULT

    # 5. Results by subject keyword (subcat was something else)
    for kw in ["financial results", "quarterly results",
               "unaudited results", "audited results",
               "results for the quarter"]:
        if kw in text:
            return QUARTERLY_RESULT

    return None  # skip


def extract_bse_code(html_text: str) -> str:
    for pat in [
        re.compile(r'BSE[:/\s]+(\d{6})', re.IGNORECASE),
        re.compile(r'bseindia\.com[^"\']*?/(\d{6})[/"\']'),
    ]:
        m = pat.search(html_text)
        if m and len(m.group(1)) == 6:
            return m.group(1)
    return ""


def discover_quarterly_results(bse_code: str) -> list[Document]:
    if not bse_code:
        print("  No BSE code — skipping.")
        return []
    try:
        from bse import BSE
    except ImportError:
        print("  'bse' not installed — run: pip install bse")
        return []

    from_date = datetime.now() - timedelta(days=365 * YEARS_BACK)
    to_date   = datetime.now()
    docs      = []

    def fetch_page(bse, page_no, retries=3):
        for attempt in range(1, retries + 1):
            try:
                return bse.announcements(
                    scripcode=bse_code, from_date=from_date,
                    to_date=to_date, page_no=page_no,
                )
            except TimeoutError:
                if attempt < retries:
                    print(f"  BSE timeout (attempt {attempt}/{retries}), retrying...")
                    time.sleep(2)
                else:
                    print("  BSE timeout — returning partial results.")
                    return None
            except Exception as e:
                print(f"  BSE error: {e}")
                return None

    with tempfile.TemporaryDirectory() as tmp:
        with BSE(download_folder=tmp) as bse:
            page_no = 1
            per_page = 20
            total = None
            while True:
                data = fetch_page(bse, page_no)
                if not data:
                    break
                table  = data.get("Table",  [])
                table1 = data.get("Table1", [])
                if total is None and table1:
                    total = table1[0].get("ROWCNT", 0)
                if not table:
                    break

                for item in table:
                    newssub    = item.get("NEWSSUB",        "")
                    attachment = item.get("ATTACHMENTNAME", "")
                    subcat     = item.get("SUBCATNAME",     "")
                    news_dt    = item.get("NEWS_DT",        "")

                    if not attachment:
                        continue

                    doc_type = classify_bse_announcement(newssub, subcat)
                    if not doc_type:
                        continue

                    # Build URL
                    try:
                        dt = datetime.strptime(news_dt[:10], "%Y-%m-%d")
                        folder = "AttachLive" if dt > datetime.now() - timedelta(days=60) else "AttachHis"
                    except Exception:
                        folder = "AttachHis"
                    pdf_url = f"https://www.bseindia.com/xml-data/corpfiling/{folder}/{attachment}"

                    label = quarter_from_text(newssub)
                    if label:
                        q_label = f"{label[0]}FY{label[1]}"
                    else:
                        q_label = label_from_bse_date(news_dt)

                    docs.append(Document(
                        document_type = doc_type,
                        label         = q_label,
                        url           = pdf_url,
                        date_display  = news_dt[:10],
                        source        = "bse",
                        subject       = newssub[:100],
                    ))

                if total and page_no * per_page >= total:
                    break
                page_no += 1

    return docs


# ══════════════════════════════════════════════════════════════════════
# DEDUPLICATION
# ══════════════════════════════════════════════════════════════════════

def deduplicate(docs: list[Document]) -> tuple[list[Document], list[tuple]]:
    """
    Keep first document per (label, document_type).
    Returns (unique_docs, duplicates_removed).
    """
    seen     = {}
    unique   = []
    dupes    = []
    for doc in docs:
        key = doc.dedup_key
        if key not in seen:
            seen[key] = doc
            unique.append(doc)
        else:
            dupes.append((key, doc.url, seen[key].url))
    return unique, dupes


# ══════════════════════════════════════════════════════════════════════
# DOWNLOADING — with credit rating HTML resolution
# ══════════════════════════════════════════════════════════════════════

def resolve_pdf_url(url: str, session: requests.Session) -> str | None:
    """
    If URL is an HTML page (e.g. ICRA rating page), find the PDF link inside it.
    Returns the final PDF URL, or None if resolution fails.
    """
    try:
        resp = session.head(url, timeout=15, allow_redirects=True)
        ct   = resp.headers.get("content-type", "")
        if "html" not in ct:
            return url   # already a direct URL

        # It's an HTML page — fetch and find PDF link
        resp = session.get(url, timeout=20)
        soup = BeautifulSoup(resp.text, "lxml")

        # Look for <a href="...pdf"> or <a> containing "download" / "pdf"
        for a in soup.find_all("a", href=True):
            href      = a["href"]
            link_text = a.get_text(" ", strip=True).lower()
            if href.lower().endswith(".pdf") or "download" in link_text or "pdf" in link_text:
                # Make absolute — fixes '/Content/assets/...' relative URLs
                return urljoin(url, href)

        # Look for embedded PDF (iframe / embed / object)
        for tag in soup.find_all(["iframe","embed","object"]):
            src = tag.get("src") or tag.get("data","")
            if src and (".pdf" in src.lower() or "pdf" in src.lower()):
                return urljoin(url, src)

        print(f"    [Could not find PDF link on HTML page: {url}]")
        return None

    except Exception as e:
        print(f"    [URL resolution error: {e}]")
        return None


def download_file(url: str, dest: Path, session: requests.Session) -> bool:
    for attempt in range(1, 4):
        try:
            # For HTML wrapper pages, resolve to actual PDF URL first
            final_url = resolve_pdf_url(url, session)
            if not final_url:
                return False

            with session.get(final_url, stream=True, timeout=60,
                             allow_redirects=True) as resp:
                resp.raise_for_status()
                ct = resp.headers.get("content-type","")
                if "html" in ct:
                    print(f"    [Still HTML after resolution — skipping]")
                    return False
                with open(dest, "wb") as f:
                    for chunk in resp.iter_content(65536):
                        if chunk:
                            f.write(chunk)

            if dest.stat().st_size < 512:
                print(f"    [File too small ({dest.stat().st_size}B) — skipping]")
                dest.unlink(missing_ok=True)
                return False
            return True

        except Exception as e:
            if attempt < 3:
                time.sleep(2 ** attempt)
            else:
                print(f"    [Failed: {e}]")
    return False


# ══════════════════════════════════════════════════════════════════════
# PDF VALIDATION
# ══════════════════════════════════════════════════════════════════════

def validate_pdf(path: Path) -> tuple[bool, str]:
    """
    Verify the file at path is a real, readable PDF with at least 1 page.

    Returns (is_valid, reason).

    Catches two BSE failure modes:
      1. BSE returns an HTML error page saved with .pdf extension.
         These start with b'<' instead of b'%PDF'.
      2. BSE returns a valid PDF container but with 0 pages (rare).

    Uses pypdf if available; falls back to magic-byte check only.
    """
    try:
        # Check magic bytes — all real PDFs start with %PDF
        with open(path, "rb") as f:
            header = f.read(5)
        if header != b"%PDF-":
            # Read a bit more to show what it actually is
            with open(path, "rb") as f:
                preview = f.read(120).decode("utf-8", errors="replace")
            return False, f"Not a PDF (starts with: {preview[:80]!r})"

        # Full parse with pypdf
        if PYPDF_AVAILABLE:
            reader = pypdf.PdfReader(str(path))
            pages  = len(reader.pages)
            if pages == 0:
                return False, "PDF opened but has 0 pages"
            return True, f"{pages} page(s)"

        # pypdf not available — magic bytes passed, accept
        return True, "magic bytes OK (pypdf not installed for full check)"

    except Exception as e:
        return False, f"pypdf error: {e}"


# ══════════════════════════════════════════════════════════════════════
# FOLDER + SKIP CHECK
# ══════════════════════════════════════════════════════════════════════

def create_folders(base: str, company: str) -> tuple:
    safe = re.sub(r'[\\/:*?"<>|]', "", company).strip()
    cd   = Path(base) / safe
    cd.mkdir(parents=True, exist_ok=True)
    folders = {}
    for dtype, fname in TYPE_TO_FOLDER.items():
        f = cd / fname
        f.mkdir(exist_ok=True)
        folders[dtype] = f
    return folders, cd


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--company", "-c")
    parser.add_argument("--url",     "-u")
    parser.add_argument("--base",    "-b")
    args = parser.parse_args()

    print("\n" + "═"*62)
    print("  Screener Document Downloader  v2")
    print("═"*62 + "\n")

    raw = args.url or args.company
    if not raw:
        print("Enter company name or Screener URL.")
        raw = input("Company / URL: ").strip()
        if not raw:
            sys.exit(1)

    base = args.base
    if not base:
        print("\nBase folder path (e.g. C:\\Users\\Ram\\Research):")
        base = input("> ").strip()
        if not base:
            sys.exit(1)

    Path(base).mkdir(parents=True, exist_ok=True)

    # ── Resolve company ────────────────────────────────────────────────
    company_name, screener_url = resolve_company(raw)
    print(f"\nCompany : {company_name}")
    print(f"URL     : {screener_url}")
    print(f"Period  : last {YEARS_BACK} years  (cutoff: {CUTOFF_YEAR})\n")

    # ── Discovery ──────────────────────────────────────────────────────
    print("─"*62)
    print("STEP 1 — DISCOVERY")
    print("─"*62)

    print("\n[Screener] Fetching static page...")
    resp = requests.get(screener_url, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    soup     = BeautifulSoup(resp.text, "lxml")
    bse_code = extract_bse_code(resp.text)
    print(f"  BSE code: {bse_code or 'NOT FOUND'}")

    annual_docs = discover_annual_reports(soup)
    print(f"  Annual Reports  : {len(annual_docs)}")

    credit_docs = discover_credit_reports(soup)
    print(f"  Credit Reports  : {len(credit_docs)}")

    print("\n[Screener] Fetching concalls (Playwright)...")
    concall_docs = discover_concalls_playwright(screener_url)
    transcripts  = [d for d in concall_docs if d.document_type == TRANSCRIPT]
    ppts         = [d for d in concall_docs if d.document_type == INVESTOR_PRESENTATION]
    print(f"  Transcripts           : {len(transcripts)}")
    print(f"  Investor Presentations: {len(ppts)}")

    print("\n[BSE] Fetching quarterly results...")
    quarterly_docs = discover_quarterly_results(bse_code)
    bse_results    = [d for d in quarterly_docs if d.document_type == QUARTERLY_RESULT]
    bse_ppts       = [d for d in quarterly_docs if d.document_type == INVESTOR_PRESENTATION]
    bse_transcripts= [d for d in quarterly_docs if d.document_type == TRANSCRIPT]
    print(f"  Quarterly Results     : {len(bse_results)}")
    print(f"  Presentations (BSE)   : {len(bse_ppts)}")
    print(f"  Transcripts (BSE)     : {len(bse_transcripts)}")

    all_docs = annual_docs + credit_docs + transcripts + ppts + quarterly_docs

    # ── Deduplication ──────────────────────────────────────────────────
    all_docs, dupes = deduplicate(all_docs)
    if dupes:
        print(f"\n  [{len(dupes)} duplicate(s) removed]")
        for (label, dtype), kept, dropped in [(d[0], d[1], d[2]) for d in dupes]:
            print(f"    {label} / {dtype} — kept first, dropped: {dropped[:60]}")

    # ── Skip check ─────────────────────────────────────────────────────
    folders, company_dir = create_folders(base, company_name)
    to_download, to_skip = [], []
    for doc in all_docs:
        existing = folders[doc.document_type] / doc.filename
        if existing.exists():
            to_skip.append(doc)
        else:
            to_download.append(doc)

    # ── Summary table ──────────────────────────────────────────────────
    print("\n" + "─"*62)
    print("STEP 2 — SUMMARY")
    print("─"*62)

    for dtype, label in [
        (ANNUAL_REPORT,         "Annual Reports"),
        (CREDIT_REPORT,         "Credit Reports"),
        (QUARTERLY_RESULT,      "Quarterly Results"),
        (INVESTOR_PRESENTATION, "Investor Presentations"),
        (TRANSCRIPT,            "Transcripts"),
    ]:
        new   = sum(1 for d in to_download if d.document_type == dtype)
        exist = sum(1 for d in to_skip    if d.document_type == dtype)
        print(f"  {label:<28}: {new:>3} new   {exist:>3} exist")

    # ── Preview ────────────────────────────────────────────────────────
    if to_download:
        print(f"\n  Files to download ({len(to_download)}):")
        current_type = None
        for doc in to_download:
            if doc.document_type != current_type:
                current_type = doc.document_type
                print(f"\n    {TYPE_TO_FOLDER[current_type]}")
            print(f"      {doc.filename}")
            print(f"        {doc.url[:72]}")

    if to_skip:
        print(f"\n  Already exist ({len(to_skip)}) — will skip.")

    if not to_download:
        print("\nNothing to download.")
        sys.exit(0)

    print(f"\n{'─'*62}")
    confirm = input(f"Download {len(to_download)} file(s)? [y/N]: ").strip().lower()
    if confirm not in ("y","yes"):
        print("Cancelled.")
        sys.exit(0)

    # ── Download ───────────────────────────────────────────────────────
    print("\n" + "─"*62)
    print("STEP 3 — DOWNLOADING")
    print("─"*62 + "\n")

    session = requests.Session()
    session.headers.update(HEADERS)
    downloaded, failed, invalid_pdfs = 0, [], []

    for doc in to_download:
        folder   = folders[doc.document_type]
        dest     = folder / doc.filename
        tmp_dest = folder / "_tmp_.pdf"
        tmp_dest.unlink(missing_ok=True)

        print(f"  [{TYPE_TO_FOLDER[doc.document_type]}] {doc.filename}")
        ok = download_file(doc.url, tmp_dest, session)

        if ok:
            # ── Validate before accepting ──────────────────────────────
            valid, reason = validate_pdf(tmp_dest)
            if valid:
                tmp_dest.rename(dest)
                print(f"  ✅ Saved  ({reason})\n")
                downloaded += 1
            else:
                tmp_dest.unlink(missing_ok=True)
                print(f"  ⚠️  Invalid PDF — {reason}")
                print(f"     Deleted: {doc.filename}\n")
                invalid_pdfs.append((doc.filename, reason))
        else:
            tmp_dest.unlink(missing_ok=True)
            print(f"  ❌ Failed\n")
            failed.append(doc.filename)

    # ── Final summary ──────────────────────────────────────────────────
    print("═"*62)
    print(f"  Downloaded : {downloaded}")
    print(f"  Skipped    : {len(to_skip)}")
    print(f"  Failed     : {len(failed)}")
    print(f"  Invalid PDF: {len(invalid_pdfs)}")
    if failed:
        print("\n  Failed downloads:")
        for f in failed:
            print(f"    • {f}")
    if invalid_pdfs:
        print("\n  Invalid PDFs (downloaded but rejected):")
        for fname, reason in invalid_pdfs:
            print(f"    • {fname}")
            print(f"      Reason: {reason}")
    print(f"\n  Saved to: {company_dir}")
    print("═"*62 + "\n")


if __name__ == "__main__":
    main()
